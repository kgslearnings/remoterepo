a=10
b=20
c="30"

def compare(x,y,z):
 if x==10 and y==20 and z=="30":
  print(True)
 
 else:
  print(False)
 
compare(a,b,c)