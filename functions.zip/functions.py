def genre():
 print("Action")
 
def artist():
 print("Batman")

def year():
 print("2000")
 
genre()

artist()

year()


 